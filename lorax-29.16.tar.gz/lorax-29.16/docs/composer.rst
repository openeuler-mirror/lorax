composer package
================

Subpackages
-----------

.. toctree::

    composer.cli

Submodules
----------

composer.http\_client module
----------------------------

.. automodule:: composer.http_client
    :members:
    :undoc-members:
    :show-inheritance:

composer.unix\_socket module
----------------------------

.. automodule:: composer.unix_socket
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: composer
    :members:
    :undoc-members:
    :show-inheritance:
