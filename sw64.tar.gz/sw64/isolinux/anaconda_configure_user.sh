# can not be time-consuming operations

isSshd=`cat /etc/passwd|grep sshd`
if [ "$isSshd" = "" ];then
    echo "sshd:x:50:50:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin" >> /etc/passwd
    echo "sshd:x:50:" >> /etc/group
fi

isLightdm=`cat /etc/passwd|grep lightdm`
if [ "$isLightdm" = "" ];then
    echo "lightdm:x:65:65:Lightdm Daemon:/var/lib/lightdm:/bin/false" >> /etc/passwd
    echo "lightdm:x:65:" >> /etc/group
fi
mkfontdir /usr/share/X11/fonts/75dpi
mkfontdir /usr/share/X11/fonts/100dpi
mkfontdir /usr/share/X11/fonts/cyrillic

sed -i 's#background=/usr/share/backgrounds/day.jpg#background=/usr/share/backgrounds/isoft-desktop-1600x1200.png#g' /etc/lightdm/lightdm-gtk-greeter.conf
echo "indicators=~hosts;~spacer;~clock;~spacer;~layout;~language;~session;~power" >> /etc/lightdm/lightdm-gtk-greeter.conf

chmod u+s /usr/bin/ping

systemctl enable dbus-broker.service
systemctl disable NetworkManager-wait-online.service
systemctl disable systemd-networkd-wait-online.service
systemctl disable multipathd.service

mv /usr/share/applications/mate-font-viewer.desktop /usr/share/applications/mate-font-viewer.desktop.bak

exit
